# 泡泡 · Mac 端 AI 对接文档

> **读者**：在 Mac 上接手的 Cursor / 其他 AI Agent  
> **目的**：快速了解已做更改、如何编译自查、如何跑演示  
> **最后更新**：2026-06-15 · 演示版 v1.0-demo（Mock AI）

---

## 0. 一句话现状

「泡泡」是一个 **SwiftUI + SwiftData iOS App**。Windows 端已完成 **Mock AI Agent 链路**（识别→推荐→HITL 保存→归位提醒）和 **完整演示旅程**；Mac 端主要负责 **Xcode 编译运行、实机/模拟器演示、录屏、排查通知与持久化**。

---

## 1. 仓库结构（Mac 路径）

```
小组作业/
├── 项目文档.md                 # 功能清单、八问、用户旅程、AI 评分
├── 用户需求.md                 # 四步框架 Step1–4（课程分析）
├── 用户与场景.md               # 产品定义与场景
├── docs/
│   ├── Mac端AI对接文档.md      # ← 本文件
│   ├── 开发执行规范.md
│   ├── 自动化执行使用说明.md   # 演示操作主文档
│   ├── 自动化执行控制.md
│   ├── 4分钟汇报PPT文案.md
│   ├── Manus-PPT生成任务稿.md
│   ├── 演示视频解说稿.md
│   └── 演示视频字幕.srt
└── 泡泡/娉℃场/                 # ← Xcode 工程根目录
    ├── 娉℃场.xcodeproj
    ├── bubble-app.md           # 工程架构速查
    ├── swiftui-gesture-feedback.md
    └── 娉℃场/                  # Swift 源码目录
        ├── __App.swift
        ├── ContentView.swift
        ├── Item.swift / SpaceNode.swift
        ├── ItemFormSheet.swift
        ├── SpaceNodeDetailView.swift
        ├── SpaceHierarchyView.swift
        ├── BubbleAgent.swift          ★ 新增
        ├── MockAIService.swift        ★ 新增
        ├── ReturnReminderService.swift ★ 新增
        ├── DemoSeedData.swift         ★ 新增
        ├── FindItGuideView.swift      ★ 新增
        ├── AppSettings.swift          ★ 新增
        └── …（表单、相机等原有文件）
```

**Mac 打开方式：**
```bash
cd "/path/to/小组作业/泡泡/娉℃场"
open 娉℃场.xcodeproj
# 或 Finder 双击 娉℃场.xcodeproj
```

> 注意：文件夹名 `娉℃场` 为 Xcode 工程名（编码显示可能异常），以 `.xcodeproj` 为准。

---

## 2. 相对「基础版」做了哪些更改

### 2.1 原有能力（改动前已有）

| 模块 | 说明 |
|------|------|
| 空间树 | `SpaceNode` 多级 CRUD，7 类空间 |
| 物品 | `Item` 手动录入，13 类 `ItemKind` |
| 搜索 | 关键词匹配名称 |
| 手势 | 左滑收藏、右滑编辑/删除 |
| 持久化 | SwiftData 本地存储 |
| 相机/相册 | UIKit 直出（避免 sheet 嵌套） |

### 2.2 本次新增（演示 / 汇报用）

| 功能 | 文件 | 行为 |
|------|------|------|
| Mock AI 识别 | `MockAIService.swift` | 拍照后延迟 1.5s，默认返回「药膏/药品」 |
| Agent 编排 | `BubbleAgent.swift` | 识别 → 查 SwiftData 推荐位置 |
| HITL 表单 | `ItemFormSheet.swift` | AI 卡片 + 预填，**必须点保存才入库** |
| 搜索关联 | `ContentView.swift` | 同容器其他物品提示 |
| 去找它 | `FindItGuideView.swift` | 路径动画 + 触觉反馈 |
| 归位提醒 | `ReturnReminderService.swift` | 本地通知 + 应用内 banner |
| 取出状态 | `Item.swift` | 新增 `checkoutAt`、`expiryDate` |
| 演示种子 | `DemoSeedData.swift` |  toolbar「导入演示」 |
| 演示参数 | `AppSettings.swift` | `demoMode=true`，提醒 15s |

### 2.3 刻意未做（不要误以为 bug）

- 真实 Vision / LLM API（全是 Mock）
- 语义 / 语音搜索
- 归位习惯分析报告
- Chatbot 对话界面

---

## 3. 架构与数据流（必读）

### 3.1 Agent 链路（非 Chatbot）

```
用户拍照
  → BubbleAgent.runItemEntryPipeline()
      → MockAIService.recognize()      // 假 Vision
      → MockAIService.recommendLocation() // 查历史 + 规则
  → ItemFormSheet 展示 AI 建议卡片
  → [HITL] 用户点「保存」
  → modelContext.insert → SwiftData

用户点「标记取出」
  → item.checkoutAt = Date()
  → ReturnReminderService.schedule()  // 15s 后通知（demoMode）
```

### 3.2 HITL 红线（不可破坏）

```swift
// ✅ Agent 只返回建议，写入只在 ItemFormSheet.save()
// ❌ 禁止在 BubbleAgent / MockAIService 内 modelContext.insert
```

### 3.3 SwiftUI 坑（见 `swiftui-gesture-feedback.md`）

- **禁止** sheet 里再套 sheet → 相机/相册用 `topmostViewController().present()`
- **禁止** 自定义 DragGesture 做右滑 → 只用 `.swipeActions`

---

## 4. Mac 环境启动

### 4.1 前置条件

- macOS + **Xcode**（项目 `IPHONEOS_DEPLOYMENT_TARGET = 26.4`，需匹配/Xcode 版本）
- iPhone **模拟器**或真机
- 首次运行允许 **通知权限**（归位提醒依赖）

### 4.2 编译运行

1. 打开 `娉℃场.xcodeproj`
2. Scheme 选 **娉℃场**，Destination 选 iPhone 模拟器（或真机）
3. **⌘R** Run
4. 若编译失败：
   - 检查 SwiftData 模型变更：`Item` 新增字段需 Clean Build（**⇧⌘K** 再 **⌘R**）
   - 新 Swift 文件在 `娉℃场/` 下会自动纳入编译（`PBXFileSystemSynchronizedRootGroup`）

### 4.3 命令行构建（可选）

```bash
cd "/path/to/小组作业/泡泡/娉℃场"
xcodebuild -scheme 娉℃场 -destination 'platform=iOS Simulator,name=iPhone 16' build
```

> Scheme / 模拟器名称以 Xcode 内实际为准。

---

## 5. 自查清单（接手的 AI 必须跑一遍）

### 5.1 编译级

- [ ] **⌘R** 无 compile error
- [ ] 启动无 crash
- [ ] 通知权限弹窗可点「允许」

### 5.2 功能级（用户旅程 J1–J8）

| ID | 操作 | 预期 |
|----|------|------|
| J1 | 空地图 → 右上角「导入演示」 | 出现家/玄关/厨房等树；弹「演示数据已导入」 |
| J3 | 搜索「车钥匙」 | 路径 +「同位置还有：门禁卡、备用钥匙」 |
| J3 | 点「去找它」 | 路径光点动画，可震动（真机） |
| J4 | 家→主卧→床头柜→药盒 → + | 打开添加物品表单 |
| J5 | 相册选图或拍照 | 「AI 正在识别…」约 1.5s → 预填药膏 |
| J5 | 点「保存」 | 药盒内出现新物品 |
| J6 | **⌘Q / 上滑杀进程** → 重开 | 数据仍在 |
| J7 | 阳台→工具箱 → 螺丝刀「标记取出」 | 显示「已取出」 |
| J8 | 等待 **15 秒** | 通知或顶部 banner →「已归位」清除 |

### 5.3 HITL 与 AI 产品约束

- [ ] 识别后 **不点保存** → 列表无新物品
- [ ] 点「取消」关闭表单 → 无写入
- [ ] AI 卡片显示置信度与「仅供参考」footer
- [ ] 无 Chatbot / 无自动 silent insert

### 5.4 课程硬性参数（Final Project）

- [ ] 数据持久化（重启仍在）
- [ ] ≥2 手势：左滑收藏、右滑删除
- [ ] ≥2 动效：FindItGuide 路径动画、归位 banner spring
- [ ] Loading / 空状态 / 按钮 disabled 反馈

---

## 6. 标准演示脚本（4 分钟 / 录视频）

**完整步骤见** `docs/自动化执行使用说明.md`。精简版：

```
1. 导入演示
2. 搜「车钥匙」→ 关联提示 → 去找它
3. 药盒 + 拍照 → AI loading → 保存
4. 杀 App 重开（证明持久化）
5. 螺丝刀标记取出 → 等 15s → 已归位
```

**录屏（Mac）：**
- 模拟器：**⌘R** 运行后，Simulator 菜单 File → Record Screen  
- 或 **⇧⌘5** 系统录屏（真机需 QuickTime 连接）

**视频素材：** `docs/演示视频解说稿.md` + `docs/演示视频字幕.srt`

---

## 7. 关键配置速查

文件：`娉℃场/AppSettings.swift`

| 变量 | 默认值 | 作用 |
|------|--------|------|
| `demoMode` | `true` | 演示模式总开关 |
| `useMockAI` | `true` | 强制 Mock，不走网络 |
| `demoReminderSeconds` | `15` | 归位提醒间隔（秒） |
| `productionReminderSeconds` | `1800` | 正式版 30 分钟 |
| `aiRecognitionDelaySeconds` | `1.5` | 模拟识别耗时 |

改 Mock 识别结果 → `MockAIService.swift` → `defaultRecognition`  
改演示物品树 → `DemoSeedData.swift` → `seed()`

---

## 8. 演示数据（导入后）

| 路径 | 物品 |
|------|------|
| 家 ▸ 玄关 ▸ 钥匙挂钩 | 车钥匙、门禁卡、备用钥匙 |
| 家 ▸ 厨房 ▸ 水槽下方柜子 | 洗洁精、垃圾袋卷、钢丝球、厨房清洁剂 |
| 家 ▸ 阳台 ▸ 工具箱 | 螺丝刀 |
| 家 ▸ 主卧 ▸ 床头柜 ▸ 药盒 | （空，留给 AI 录入演示） |

---

## 9. 常见问题（Mac 端）

| 现象 | 处理 |
|------|------|
| 搜不到车钥匙 | 先点「导入演示」；地图非空时按钮隐藏 |
| 没收到归位通知 | 系统设置 → 通知 → 泡泡 → 允许；等 **15s** 非 30min |
| 模拟器拍照 | 用「从相册选择」代替相机 |
| AI 总是「药膏」 | **预期行为**（Mock）；保存前可改字段 |
| 编译 SwiftData 报错 | Clean Build；检查 `Item` 新字段 |
| 中文路径问题 | 尽量用 Xcode 打开 `.xcodeproj`，少依赖终端 cd 乱码路径 |

---

## 10. 文档索引（勿重复造轮子）

| 需求 | 读哪个文件 |
|------|------------|
| 演示怎么点 | `docs/自动化执行使用说明.md` |
| Agent 控制逻辑 | `docs/自动化执行控制.md` |
| 代码规范 / 验收 | `docs/开发执行规范.md` |
| 功能与八问全文 | `项目文档.md` |
| 四步框架分析 | `用户需求.md` |
| 4 分钟汇报文案 | `docs/4分钟汇报PPT文案.md` |
| 工程文件说明 | `泡泡/娉℃场/bubble-app.md` |
| 手势避坑 | `泡泡/娉℃场/swiftui-gesture-feedback.md` |

---

## 11. 后续允许 / 禁止的改动

### ✅ 欢迎（Mac 端典型任务）

- 修复编译、通知权限、SwiftData 迁移问题
- 替换 placeholder 为真实 App 截图到 PPT
- 录屏、微调 UI、修 crash
- 接入真实 Vision API（保留 Mock 降级 + HITL 不变）

### ❌ 禁止（会破坏演示 / 评分）

- 去掉 HITL，AI 自动 `insert`
- 改成 Chatbot 主界面
- sheet 嵌套 sheet 打开相机
- 演示前把 `demoMode` 改成 false 却不告知（提醒变 30 分钟）
- 删除 `DemoSeedData` / `MockAIService` 导致无法离线演示

---

## 12. 给新 AI 的启动提示词（可复制）

```
你是 Mac 端接手的 AI。请先阅读 docs/Mac端AI对接文档.md，
打开 泡泡/娉℃场/娉℃场.xcodeproj 编译运行，按第 5 节自查清单
跑通 J1–J8 演示旅程。所有 AI 能力均为 Mock，HITL 保存不可破坏。
遇到问题先查 docs/自动化执行使用说明.md 第 5 节 FAQ。
```

---

## 13. 变更文件清单（供 diff 对照）

**新增 7 个 Swift 文件：**
`AppSettings.swift` · `MockAIService.swift` · `BubbleAgent.swift` · `ReturnReminderService.swift` · `DemoSeedData.swift` · `FindItGuideView.swift`

**主要修改：**
`Item.swift` · `ItemFormSheet.swift` · `ContentView.swift` · `SpaceNodeDetailView.swift` · `__App.swift` · `Info.plist`（通知描述）

**新增文档：**
`项目文档.md` · `docs/*`（见第 1 节目录）

---

*对接文档结束。Mac 端优先任务：编译通过 → J1–J8 自查 → 录屏/汇报。*
