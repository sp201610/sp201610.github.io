//
//  NewSpaceNodeSheet.swift
//  泡泡
//
//  半屏表单：为收纳地图添加一处真实空间。
//

import PhotosUI
import SwiftData
import SwiftUI
import UIKit

struct NewSpaceNodeSheet: View {
    var onSaved: (SpaceNode) -> Void = { _ in }

    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \SpaceNode.sortOrder) private var allNodes: [SpaceNode]

    @State private var name: String = ""
    @State private var kind: SpaceKind = .room
    @State private var parent: SpaceNode?
    @State private var photoData: Data?
    @State private var customKindName: String = ""
    @State private var showValidationAlert = false

    private var trimmedName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        NavigationStack {
            Form {
                SpaceNodeFormBody(
                    name: $name,
                    kind: $kind,
                    parent: $parent,
                    photoData: $photoData,
                    customKindName: $customKindName,
                    allNodes: allNodes,
                    excludeSubtreeRoot: nil
                )
            }
            .navigationTitle("新拓一处空间")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        save()
                    }
                    .disabled(trimmedName.isEmpty)
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .alert("请填写名称", isPresented: $showValidationAlert) {
            Button("好的", role: .cancel) {}
        } message: {
            Text("给这处空间起一个简短名称后再保存。")
        }
    }

    private func save() {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            showValidationAlert = true
            return
        }

        let siblings: [SpaceNode]
        if let p = parent {
            siblings = allNodes.filter { $0.parent?.persistentModelID == p.persistentModelID }
        } else {
            siblings = allNodes.filter { $0.parent == nil }
        }
        let order = SpaceNode.nextSortOrder(among: siblings)

        let node = SpaceNode(
            name: trimmed,
            kind: kind,
            sortOrder: order,
            photoData: photoData,
            parent: parent,
            customKindName: kind == .custom ? customKindName.trimmingCharacters(in: .whitespacesAndNewlines) : ""
        )
        modelContext.insert(node)
        onSaved(node)
        dismiss()
    }
}

#Preview {
    NewSpaceNodeSheet()
        .modelContainer(for: [SpaceNode.self, Item.self], inMemory: true)
}
