//
//  ContentView.swift
//  泡泡
//
//  Created by Apple on 2026/4/22.
//

import SwiftData
import SwiftUI

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \SpaceNode.sortOrder) private var allNodes: [SpaceNode]
    @Query(sort: \Item.sortOrder) private var allItems: [Item]

    @State private var showNewSheet = false
    @State private var expanded = Set<PersistentIdentifier>()
    @State private var didSeedExpansion = false
    @State private var searchText = ""
    @State private var findItItem: Item?
    @State private var showSeedSuccess = false

    private var roots: [SpaceNode] {
        SpaceNode.roots(from: allNodes)
    }

    private var filteredSpaces: [SpaceNode] {
        guard !searchText.isEmpty else { return [] }
        return allNodes.filter {
            $0.name.localizedCaseInsensitiveContains(searchText)
        }
    }

    private var filteredItems: [Item] {
        guard !searchText.isEmpty else { return [] }
        return allItems.filter {
            $0.name.localizedCaseInsensitiveContains(searchText)
                || $0.kind.title.localizedCaseInsensitiveContains(searchText)
        }
    }

    private var isMapEmpty: Bool {
        allNodes.isEmpty
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                Color(.systemGroupedBackground)
                    .ignoresSafeArea()

                if searchText.isEmpty {
                    SpaceHierarchyView(roots: roots, expanded: $expanded)
                        .padding(.horizontal, 8)
                        .padding(.top, 8)
                        .safeAreaInset(edge: .bottom, spacing: 0) {
                            Color.clear.frame(height: 88)
                        }
                } else {
                    searchResults
                }

                if searchText.isEmpty {
                    addButton
                }
            }
            .navigationTitle("泡泡 · 收纳地图")
            .navigationBarTitleDisplayMode(.large)
            .searchable(
                text: $searchText,
                placement: .navigationBarDrawer(displayMode: .always),
                prompt: "搜索空间和物品"
            )
            .toolbar {
                if isMapEmpty {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("导入演示") {
                            if DemoSeedData.seed(into: modelContext) {
                                showSeedSuccess = true
                                Task { @MainActor in
                                    try? await Task.sleep(nanoseconds: 150_000_000)
                                    expanded = Set(allNodes.filter { !$0.children.isEmpty }.map(\.persistentModelID))
                                }
                            }
                        }
                    }
                }
            }
            .sheet(isPresented: $showNewSheet) {
                NewSpaceNodeSheet { saved in
                    expandAncestors(of: saved)
                }
            }
            .sheet(item: $findItItem) { item in
                FindItGuideView(item: item)
            }
            .alert("演示数据已导入", isPresented: $showSeedSuccess) {
                Button("好的", role: .cancel) {}
            } message: {
                Text("现在可以搜索「车钥匙」体验完整旅程。")
            }
            .overlay(alignment: .top) {
                returnReminderBanner
            }
            .task {
                guard !didSeedExpansion else { return }
                didSeedExpansion = true
                expanded = Set(allNodes.filter { !$0.children.isEmpty }.map(\.persistentModelID))
            }
        }
    }

    @ViewBuilder
    private var returnReminderBanner: some View {
        if let banner = ReturnReminderService.shared.pendingBanner {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    Image(systemName: "bell.badge.fill")
                        .foregroundStyle(.orange)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("「\(banner.itemName)」还未归位")
                            .font(.subheadline.weight(.semibold))
                        Text("请放回 \(banner.homePath)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("已归位") {
                        if let item = allItems.first(where: { $0.persistentModelID == banner.itemID }) {
                            ReturnReminderService.shared.markReturned(item)
                        }
                    }
                    .font(.caption.weight(.semibold))
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
                }
                .padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .padding(.horizontal)
                .padding(.top, 8)
                Spacer()
            }
            .transition(.move(edge: .top).combined(with: .opacity))
            .animation(.spring(duration: 0.35), value: banner.id)
        }
    }

    // MARK: - 搜索结果

    private var searchResults: some View {
        List {
            if !filteredSpaces.isEmpty {
                Section("空间") {
                    ForEach(filteredSpaces) { space in
                        NavigationLink(destination: SpaceNodeDetailView(node: space)) {
                            HStack(spacing: 10) {
                                Image(systemName: space.kind.systemImage)
                                    .symbolRenderingMode(.hierarchical)
                                    .foregroundStyle(.secondary)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(space.name)
                                        .font(.body.weight(.medium))
                                    Text(space.pathString)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }
            }

            if !filteredItems.isEmpty {
                Section("物品") {
                    ForEach(filteredItems) { item in
                        itemSearchRow(item)
                    }
                }
            }

            if filteredSpaces.isEmpty && filteredItems.isEmpty {
                ContentUnavailableView.search(text: searchText)
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
    }

    @ViewBuilder
    private func itemSearchRow(_ item: Item) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Text(item.kind.emoji)
                    .font(.title2)
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.name)
                        .font(.body.weight(.semibold))
                    if let space = item.space {
                        Label(space.pathString, systemImage: "mappin")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Text(item.kind.title)
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
                Spacer()
            }

            if let siblings = BubbleAgent.siblingSummary(for: item) {
                HStack(alignment: .top, spacing: 6) {
                    Image(systemName: "sparkles")
                        .font(.caption)
                        .foregroundStyle(Color.accentColor)
                    Text("同位置还有：\(siblings)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.accentColor.opacity(0.06), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            }

            HStack(spacing: 10) {
                Button {
                    findItItem = item
                } label: {
                    Label("去找它", systemImage: "location.fill")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                if let space = item.space {
                    NavigationLink(destination: SpaceNodeDetailView(node: space)) {
                        Text("查看空间")
                            .font(.subheadline)
                    }
                    .buttonStyle(.bordered)
                }
            }
        }
        .padding(.vertical, 6)
    }

    private var addButton: some View {
        Button {
            showNewSheet = true
        } label: {
            Image(systemName: "plus")
                .font(.title2.weight(.semibold))
                .foregroundStyle(Color(.systemBackground))
                .frame(width: 56, height: 56)
                .background(Color.accentColor, in: Circle())
                .shadow(color: .black.opacity(0.14), radius: 10, y: 4)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("为收纳地图添加一处空间")
        .padding(.trailing, 24)
        .padding(.bottom, 24)
    }

    private func expandAncestors(of node: SpaceNode) {
        var current: SpaceNode? = node.parent
        while let p = current {
            expanded.insert(p.persistentModelID)
            current = p.parent
        }
    }
}

#Preview {
    ContentView()
        .modelContainer(for: [SpaceNode.self, Item.self], inMemory: true)
}
