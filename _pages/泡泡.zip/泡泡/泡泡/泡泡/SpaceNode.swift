//
//  SpaceNode.swift
//  泡泡
//
//  收纳地图中的空间节点：支持层级、类型与照片记忆。
//

import Foundation
import SwiftData

/// 收纳空间类型（共 7 类，持久化使用 `rawValue` 写入 `kindRaw`）。
enum SpaceKind: String, CaseIterable, Identifiable, Sendable {
    case room
    case cabinet
    case drawer
    case storageBox
    case flatSurface
    case bag
    case custom

    var id: String { rawValue }

    var title: String {
        switch self {
        case .room: return "房间"
        case .cabinet: return "柜子"
        case .drawer: return "抽屉"
        case .storageBox: return "收纳盒"
        case .flatSurface: return "平面"
        case .bag: return "包"
        case .custom: return "自定义 / 其他"
        }
    }

    /// 列表与表单共用的 SF Symbol，与类型语义一致。
    var systemImage: String {
        switch self {
        case .room: return "house.fill"
        case .cabinet: return "cabinet.fill"
        case .drawer: return "tray.2.fill"
        case .storageBox: return "shippingbox.fill"
        case .flatSurface: return "table.furniture.fill"
        case .bag: return "handbag.fill"
        case .custom: return "folder.fill"
        }
    }

    /// 兼容旧版本 `kindRaw`（如 `shelf`、`other`）。
    static func resolved(from stored: String) -> SpaceKind {
        switch stored {
        case "room": return .room
        case "cabinet": return .cabinet
        case "drawer": return .drawer
        case "storageBox": return .storageBox
        case "flatSurface": return .flatSurface
        case "bag": return .bag
        case "custom": return .custom
        case "shelf": return .flatSurface
        case "other": return .custom
        default:
            return SpaceKind(rawValue: stored) ?? .custom
        }
    }
}

@Model
final class SpaceNode {
    var name: String
    var kindRaw: String
    var sortOrder: Int
    var createdAt: Date

    @Attribute(.externalStorage)
    var photoData: Data?

    var parent: SpaceNode?

    @Relationship(deleteRule: .cascade, inverse: \SpaceNode.parent)
    var children: [SpaceNode] = []

    @Relationship(deleteRule: .cascade, inverse: \Item.space)
    var items: [Item] = []

    /// 收藏：同父级下置顶显示；持久化。
    var isFavorite: Bool = false

    /// 当空间类型为「自定义」时，用户自行命名的类型名称。
    var customKindName: String = ""

    init(
        name: String,
        kind: SpaceKind,
        sortOrder: Int,
        photoData: Data? = nil,
        parent: SpaceNode? = nil,
        isFavorite: Bool = false,
        customKindName: String = ""
    ) {
        self.name = name
        self.kindRaw = kind.rawValue
        self.sortOrder = sortOrder
        self.createdAt = Date()
        self.photoData = photoData
        self.parent = parent
        self.isFavorite = isFavorite
        self.customKindName = customKindName
    }

    var kind: SpaceKind {
        SpaceKind.resolved(from: kindRaw)
    }

    /// 从根到自身的完整路径字符串。
    var pathString: String {
        var parts: [String] = [name]
        var current = parent
        while let p = current {
            parts.insert(p.name, at: 0)
            current = p.parent
        }
        return parts.joined(separator: " ▸ ")
    }

    /// 列表展示用的类型名称：自定义类型优先取用户命名，否则回退到预设标题。
    var kindDisplayName: String {
        if kind == .custom, !customKindName.isEmpty {
            return customKindName
        }
        return kind.title
    }
}

extension SpaceNode {
    /// 同父级下排序：收藏在前，其次按 `sortOrder`（保持组内原有顺序）。
    static func compareSiblingOrder(_ a: SpaceNode, _ b: SpaceNode) -> Bool {
        if a.isFavorite != b.isFavorite {
            return a.isFavorite && !b.isFavorite
        }
        return a.sortOrder < b.sortOrder
    }

    static func nextSortOrder(among siblings: [SpaceNode]) -> Int {
        (siblings.map(\.sortOrder).max() ?? -1) + 1
    }

    static func roots(from all: [SpaceNode]) -> [SpaceNode] {
        all.filter { $0.parent == nil }.sorted(by: compareSiblingOrder)
    }

    func sortedChildren() -> [SpaceNode] {
        children.sorted(by: Self.compareSiblingOrder)
    }

    /// 用于「上层空间」选择器：深度优先展平，附带缩进层级。
    static func depthFirstPairs(from roots: [SpaceNode]) -> [(node: SpaceNode, depth: Int)] {
        var result: [(node: SpaceNode, depth: Int)] = []
        func walk(_ nodes: [SpaceNode], depth: Int) {
            for node in nodes.sorted(by: compareSiblingOrder) {
                result.append((node: node, depth: depth))
                walk(node.sortedChildren(), depth: depth + 1)
            }
        }
        walk(roots, depth: 0)
        return result
    }

    /// 选择上层空间时不可选的节点 id：自身及其全部后代，避免循环引用。
    static func invalidUpperSpacePickerSubtree(from root: SpaceNode) -> Set<PersistentIdentifier> {
        var ids: Set<PersistentIdentifier> = [root.persistentModelID]
        for child in root.children {
            ids.formUnion(invalidUpperSpacePickerSubtree(from: child))
        }
        return ids
    }
}
