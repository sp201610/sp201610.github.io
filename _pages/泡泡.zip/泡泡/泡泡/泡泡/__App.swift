//
//  __App.swift
//  泡泡
//
//  Created by Apple on 2026/4/22.
//

import SwiftData
import SwiftUI

@main
struct __App: App {
    private static let modelContainer: ModelContainer = {
        let schema = Schema([SpaceNode.self, Item.self])
        let configuration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
        do {
            return try ModelContainer(for: schema, configurations: [configuration])
        } catch {
            fatalError("无法创建 SwiftData 容器：\(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .task {
                    ReturnReminderService.shared.configure()
                    await ReturnReminderService.shared.requestAuthorization()
                }
        }
        .modelContainer(Self.modelContainer)
    }
}
