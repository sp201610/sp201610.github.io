//
//  EditSpaceNodeSheet.swift
//  泡泡
//
//  半屏编辑：更新已有空间节点。
//

import PhotosUI
import SwiftData
import SwiftUI
import UIKit

struct EditSpaceNodeSheet: View {
    let node: SpaceNode
    var onSaved: (SpaceNode) -> Void = { _ in }

    @Environment(\.dismiss) private var dismiss
    @Query(sort: \SpaceNode.sortOrder) private var allNodes: [SpaceNode]

    @State private var name: String
    @State private var kind: SpaceKind
    @State private var parent: SpaceNode?
    @State private var photoData: Data?
    @State private var customKindName: String
    @State private var showValidationAlert = false

    init(node: SpaceNode, onSaved: @escaping (SpaceNode) -> Void = { _ in }) {
        self.node = node
        self.onSaved = onSaved
        _name = State(initialValue: node.name)
        _kind = State(initialValue: node.kind)
        _parent = State(initialValue: node.parent)
        _photoData = State(initialValue: node.photoData)
        _customKindName = State(initialValue: node.customKindName)
    }

    private var trimmedName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        NavigationStack {
            Form {
                SpaceNodeFormBody(
                    name: $name,
                    kind: $kind,
                    parent: $parent,
                    photoData: $photoData,
                    customKindName: $customKindName,
                    allNodes: allNodes,
                    excludeSubtreeRoot: node
                )
            }
            .navigationTitle("编辑空间")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        save()
                    }
                    .disabled(trimmedName.isEmpty)
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .alert("请填写名称", isPresented: $showValidationAlert) {
            Button("好的", role: .cancel) {}
        } message: {
            Text("给这处空间起一个简短名称后再保存。")
        }
    }

    private func save() {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            showValidationAlert = true
            return
        }

        let invalid = SpaceNode.invalidUpperSpacePickerSubtree(from: node)
        if let p = parent, invalid.contains(p.persistentModelID) {
            return
        }

        let oldParentID = node.parent?.persistentModelID
        let newParentID = parent?.persistentModelID

        node.name = trimmed
        node.kindRaw = kind.rawValue
        node.photoData = photoData
        node.customKindName = kind == .custom ? customKindName.trimmingCharacters(in: .whitespacesAndNewlines) : ""

        if oldParentID != newParentID {
            let siblings = allNodes.filter {
                $0.parent?.persistentModelID == newParentID
                    && $0.persistentModelID != node.persistentModelID
            }
            node.sortOrder = SpaceNode.nextSortOrder(among: siblings)
            node.parent = parent
        }

        onSaved(node)
        dismiss()
    }
}

#Preview {
    let schema = Schema([SpaceNode.self, Item.self])
    let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)
    let container = try! ModelContainer(for: schema, configurations: [config])
    let n = SpaceNode(name: "预览", kind: .room, sortOrder: 0)
    container.mainContext.insert(n)
    return EditSpaceNodeSheet(node: n)
        .modelContainer(container)
}
