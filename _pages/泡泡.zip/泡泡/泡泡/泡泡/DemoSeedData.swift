//
//  DemoSeedData.swift
//  泡泡
//
//  一键导入演示数据，支撑 J1–J9 用户旅程。
//

import Foundation
import SwiftData

enum DemoSeedData {
    static let seedFlagKey = "paopao.demoSeeded"

    static func hasSeeded() -> Bool {
        UserDefaults.standard.bool(forKey: seedFlagKey)
    }

    static func markSeeded() {
        UserDefaults.standard.set(true, forKey: seedFlagKey)
    }

    /// 是否已有用户数据（有根节点即视为非空）。
    static func isEmpty(context: ModelContext) -> Bool {
        let descriptor = FetchDescriptor<SpaceNode>()
        let count = (try? context.fetchCount(descriptor)) ?? 0
        return count == 0
    }

    @discardableResult
    static func seed(into context: ModelContext) -> Bool {
        guard isEmpty(context: context) else { return false }

        func space(
            _ name: String,
            kind: SpaceKind,
            order: Int,
            parent: SpaceNode? = nil
        ) -> SpaceNode {
            let node = SpaceNode(name: name, kind: kind, sortOrder: order, parent: parent)
            context.insert(node)
            return node
        }

        func item(
            _ name: String,
            kind: ItemKind,
            order: Int,
            in space: SpaceNode
        ) {
            let i = Item(name: name, kind: kind, sortOrder: order, space: space)
            context.insert(i)
        }

        let home = space("家", kind: .room, order: 0)

        let entry = space("玄关", kind: .room, order: 0, parent: home)
        let keyHook = space("钥匙挂钩", kind: .flatSurface, order: 0, parent: entry)
        item("车钥匙", kind: .keys, order: 0, in: keyHook)
        item("门禁卡", kind: .keys, order: 1, in: keyHook)
        item("备用钥匙", kind: .keys, order: 2, in: keyHook)

        let bedroom = space("主卧", kind: .room, order: 1, parent: home)
        let nightstand = space("床头柜", kind: .drawer, order: 0, parent: bedroom)
        _ = space("药盒", kind: .storageBox, order: 0, parent: nightstand)

        let kitchen = space("厨房", kind: .room, order: 2, parent: home)
        let underSink = space("水槽下方柜子", kind: .cabinet, order: 0, parent: kitchen)
        item("洗洁精", kind: .toiletries, order: 0, in: underSink)
        item("垃圾袋卷", kind: .toiletries, order: 1, in: underSink)
        item("钢丝球", kind: .tools, order: 2, in: underSink)
        item("厨房清洁剂", kind: .toiletries, order: 3, in: underSink)

        let living = space("客厅", kind: .room, order: 3, parent: home)
        _ = space("茶几", kind: .flatSurface, order: 0, parent: living)

        let balcony = space("阳台", kind: .room, order: 4, parent: home)
        let toolbox = space("工具箱", kind: .storageBox, order: 0, parent: balcony)
        item("螺丝刀", kind: .tools, order: 0, in: toolbox)

        markSeeded()
        return true
    }
}
