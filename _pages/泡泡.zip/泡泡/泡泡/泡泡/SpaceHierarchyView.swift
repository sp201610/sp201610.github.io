//
//  SpaceHierarchyView.swift
//  泡泡
//
//  层级展示、展开 / 折叠、左滑编辑与删除、右滑收藏。
//

import SwiftData
import SwiftUI
import UIKit

private struct VisibleHierarchyRow: Identifiable {
    let id: PersistentIdentifier
    let node: SpaceNode
    let depth: Int
}

private struct EditSheetTarget: Identifiable {
    let id: PersistentIdentifier
    let node: SpaceNode
}

struct SpaceHierarchyView: View {
    @Environment(\.modelContext) private var modelContext

    let roots: [SpaceNode]
    @Binding var expanded: Set<PersistentIdentifier>

    @State private var nodePendingDelete: SpaceNode?
    @State private var editTarget: EditSheetTarget?
    @State private var detailNode: SpaceNode?

    private var visibleRows: [VisibleHierarchyRow] {
        var rows: [VisibleHierarchyRow] = []
        func walk(_ nodes: [SpaceNode], depth: Int) {
            for node in nodes.sorted(by: SpaceNode.compareSiblingOrder) {
                rows.append(VisibleHierarchyRow(id: node.persistentModelID, node: node, depth: depth))
                if !node.children.isEmpty, expanded.contains(node.persistentModelID) {
                    walk(node.sortedChildren(), depth: depth + 1)
                }
            }
        }
        walk(roots, depth: 0)
        return rows
    }

    var body: some View {
        Group {
            if roots.isEmpty {
                ContentUnavailableView(
                    "收纳地图还是空的",
                    systemImage: "map",
                    description: Text("点击右下角加号，把家里的每一处真实空间慢慢补全。")
                )
                .padding(.top, 48)
            } else {
                List {
                    ForEach(visibleRows) { row in
                        SpaceNodeRowVisual(
                            node: row.node,
                            depth: row.depth,
                            expanded: $expanded,
                            onTap: { detailNode = row.node }
                        )
                        .listRowInsets(EdgeInsets(top: 6, leading: 4, bottom: 6, trailing: 4))
                            .listRowSeparator(.hidden)
                            .listRowBackground(Color.clear)
                            .swipeActions(edge: .leading, allowsFullSwipe: true) {
                                Button {
                                    row.node.isFavorite.toggle()
                                } label: {
                                    Image(systemName: "star.fill")
                                }
                                .tint(.yellow)
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                
                                Button(role: .destructive) {
                                    nodePendingDelete = row.node
                                } label: {
                                    Label("删除", systemImage: "trash")
                                }
                                
                                Button {
                                    editTarget = EditSheetTarget(id: row.node.persistentModelID, node: row.node)
                                } label: {
                                    Label("编辑", systemImage: "pencil")
                                }
                                .tint(.blue)
                            }
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .navigationDestination(item: $detailNode) { node in
                    SpaceNodeDetailView(node: node)
                }
            }
        }
        .alert(
            "删除确认",
            isPresented: Binding(
                get: { nodePendingDelete != nil },
                set: { if !$0 { nodePendingDelete = nil } }
            ),
            presenting: nodePendingDelete
        ) { node in
            Button("取消", role: .cancel) {
                nodePendingDelete = nil
            }
            Button("删除", role: .destructive) {
                confirmDelete(node)
            }
        } message: { node in
            Text("确定要删除「\(node.name)」及其内部的所有子空间和物品吗？")
        }
        .sheet(item: $editTarget) { target in
            EditSpaceNodeSheet(node: target.node) { saved in
                var current: SpaceNode? = saved.parent
                while let p = current {
                    expanded.insert(p.persistentModelID)
                    current = p.parent
                }
            }
        }
    }

    /// 收集该节点及所有后代在展开状态中的 id，避免删除后 `expanded` 残留无效引用。
    private static func subtreePersistentIDs(root: SpaceNode) -> Set<PersistentIdentifier> {
        var ids: Set<PersistentIdentifier> = [root.persistentModelID]
        for child in root.children {
            ids.formUnion(subtreePersistentIDs(root: child))
        }
        return ids
    }

    private func confirmDelete(_ node: SpaceNode) {
        let idsToRemove = Self.subtreePersistentIDs(root: node)
        expanded.subtract(idsToRemove)
        modelContext.delete(node)
        nodePendingDelete = nil
    }
}

// MARK: - 单行展示（无递归，由上层 List 扁平化）

private struct SpaceNodeRowVisual: View {
    @Bindable var node: SpaceNode
    let depth: Int
    @Binding var expanded: Set<PersistentIdentifier>
    var onTap: () -> Void = {}

    private var children: [SpaceNode] { node.sortedChildren() }
    private var hasChildren: Bool { !children.isEmpty }
    private var isExpanded: Bool { expanded.contains(node.persistentModelID) }

    var body: some View {
        rowContent
    }

    private var rowContent: some View {
        HStack(alignment: .center, spacing: 10) {
            Group {
                if hasChildren {
                    Button {
                        toggleExpanded()
                    } label: {
                        Image(systemName: isExpanded ? "chevron.down.circle.fill" : "chevron.right.circle.fill")
                            .font(.title3)
                            .symbolRenderingMode(.hierarchical)
                            .foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(isExpanded ? "折叠子空间" : "展开子空间")
                } else {
                    Image(systemName: "circle.fill")
                        .font(.system(size: 6))
                        .foregroundStyle(.quaternary)
                        .frame(width: 28, height: 28)
                }
            }
            .frame(width: 28, alignment: .center)

            HStack(spacing: 10) {
                typeKindIcon

                HStack(alignment: .center, spacing: 6) {
                    if node.isFavorite {
                        Image(systemName: "star.fill")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(Color(UIColor.systemYellow))
                            .frame(width: 18)
                            .accessibilityLabel("已收藏")
                    }
                    VStack(alignment: .leading, spacing: 4) {
                        Text(node.name)
                            .font(.body.weight(.semibold))
                            .foregroundStyle(.primary)
                            .lineLimit(2)
                            .minimumScaleFactor(0.85)
                        Text(node.kindDisplayName)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                    }
                }

                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
            .onTapGesture { onTap() }
            .offset(x: -6)
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 12)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color(.secondarySystemGroupedBackground))
        )
        .padding(.leading, CGFloat(depth) * 20)
    }

    private var typeKindIcon: some View {
        Image(systemName: node.kind.systemImage)
            .font(.system(size: 20, weight: .medium))
            .symbolRenderingMode(.hierarchical)
            .foregroundStyle(Color.secondary)
            .frame(width: 28, height: 28, alignment: .center)
            .accessibilityHidden(true)
    }

    private func toggleExpanded() {
        let id = node.persistentModelID
        if expanded.contains(id) {
            expanded.remove(id)
        } else {
            expanded.insert(id)
        }
    }
}
