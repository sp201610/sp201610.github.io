//
//  AppSettings.swift
//  泡泡
//
//  全局演示 / 自动化控制参数。
//

import Foundation

enum AppSettings {
    /// 演示模式：短提醒间隔、Mock AI、工具栏导入演示数据。
    static var demoMode: Bool = true

    /// 强制使用 Mock AI，不调用网络 API。
    static var useMockAI: Bool = true

    /// 演示模式归位提醒间隔（秒）。
    static var demoReminderSeconds: TimeInterval = 15

    /// 正式版归位提醒间隔（秒）。
    static var productionReminderSeconds: TimeInterval = 30 * 60

    /// 模拟 AI 识别耗时（秒）。
    static var aiRecognitionDelaySeconds: TimeInterval = 1.5

    static var reminderInterval: TimeInterval {
        demoMode ? demoReminderSeconds : productionReminderSeconds
    }
}
