//
//  MockAIService.swift
//  泡泡
//
//  演示降级：预置伪 AI 识别与推荐响应，不依赖网络。
//

import Foundation
import SwiftData

struct AIRecognitionResult: Sendable {
    let name: String
    let kind: ItemKind
    let confidence: Double
    let reasoning: String
}

struct AILocationRecommendation: Sendable {
    let space: SpaceNode?
    let reason: String
    let confidence: Double
}

enum MockAIService {
    private static let defaultRecognition = AIRecognitionResult(
        name: "药膏",
        kind: .medicine,
        confidence: 0.92,
        reasoning: "识别为常见外用药膏包装（演示 Mock 响应）"
    )

    private static let lowConfidenceRecognition = AIRecognitionResult(
        name: "",
        kind: .electronics,
        confidence: 0.38,
        reasoning: "图像不够清晰，无法确定物品类型"
    )

    /// 模拟 Vision 识别：固定延迟 + 规则表匹配。
    static func recognize(from photoData: Data?) async -> AIRecognitionResult {
        let delay = UInt64(AppSettings.aiRecognitionDelaySeconds * 1_000_000_000)
        try? await Task.sleep(nanoseconds: delay)

        guard photoData != nil else {
            return lowConfidenceRecognition
        }

        // 演示默认：药膏录入场景（场景二）
        return defaultRecognition
    }

    /// 根据名称关键词覆盖识别（便于扩展演示）。
    static func recognizeWithHint(nameHint: String) -> AIRecognitionResult {
        let hint = nameHint.lowercased()
        if hint.contains("钥匙") {
            return AIRecognitionResult(
                name: nameHint.isEmpty ? "车钥匙" : nameHint,
                kind: .keys,
                confidence: 0.95,
                reasoning: "识别为钥匙类物品"
            )
        }
        if hint.contains("螺丝") {
            return AIRecognitionResult(
                name: "螺丝刀",
                kind: .tools,
                confidence: 0.91,
                reasoning: "识别为维修工具"
            )
        }
        if hint.contains("垃圾袋") {
            return AIRecognitionResult(
                name: "垃圾袋卷",
                kind: .toiletries,
                confidence: 0.88,
                reasoning: "识别为厨房耗材"
            )
        }
        return defaultRecognition
    }

    /// 基于历史同类物品统计 + 预置路径规则推荐位置。
    static func recommendLocation(
        for kind: ItemKind,
        defaultSpace: SpaceNode,
        allItems: [Item],
        allNodes: [SpaceNode]
    ) -> AILocationRecommendation {
        let sameKind = allItems.filter { $0.kind == kind && $0.space != nil }
        if !sameKind.isEmpty {
            let counts = Dictionary(grouping: sameKind, by: { $0.space!.persistentModelID })
            if let bestID = counts.max(by: { $0.value.count < $1.value.count })?.key,
               let space = allNodes.first(where: { $0.persistentModelID == bestID }) {
                return AILocationRecommendation(
                    space: space,
                    reason: "你过去 \(counts[bestID]!.count) 次把\(kind.title)放在这里",
                    confidence: 0.85
                )
            }
        }

        // 预置规则：按类型匹配演示空间名
        let targetName: String? = switch kind {
        case .medicine: "药盒"
        case .keys: "钥匙挂钩"
        case .tools: "工具箱"
        case .toiletries: "水槽下方柜子"
        default: nil
        }

        if let targetName,
           let space = allNodes.first(where: { $0.name.contains(targetName) }) {
            return AILocationRecommendation(
                space: space,
                reason: "同类物品通常放在「\(space.name)」",
                confidence: 0.78
            )
        }

        return AILocationRecommendation(
            space: defaultSpace,
            reason: "暂无历史记录，建议放在当前空间",
            confidence: 0.55
        )
    }
}
