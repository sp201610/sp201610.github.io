//
//  FindItGuideView.swift
//  泡泡
//
//  「去找它」：路径分段高亮 + 轻量动画 + 触觉反馈。
//

import SwiftUI
import UIKit

struct FindItGuideView: View {
    let item: Item
    @Environment(\.dismiss) private var dismiss

    @State private var litIndex: Int = -1
    @State private var pulse = false

    private var pathSegments: [String] {
        guard let space = item.space else { return [item.name] }
        var parts = space.pathString.components(separatedBy: " ▸ ")
        parts.append(item.name)
        return parts
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 28) {
                Text("跟着光走，就能找到它")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 0) {
                    ForEach(Array(pathSegments.enumerated()), id: \.offset) { index, segment in
                        HStack(spacing: 14) {
                            ZStack {
                                Circle()
                                    .fill(index <= litIndex ? Color.accentColor : Color(.systemGray4))
                                    .frame(width: 14, height: 14)
                                    .scaleEffect(index == litIndex && pulse ? 1.35 : 1)
                                    .animation(.easeInOut(duration: 0.45).repeatCount(2, autoreverses: true), value: pulse)

                                if index == litIndex {
                                    Circle()
                                        .stroke(Color.accentColor.opacity(0.4), lineWidth: 3)
                                        .frame(width: 26, height: 26)
                                        .scaleEffect(pulse ? 1.2 : 0.8)
                                        .opacity(pulse ? 0 : 0.8)
                                }
                            }
                            .frame(width: 28)

                            VStack(alignment: .leading, spacing: 2) {
                                Text(segment)
                                    .font(index == pathSegments.count - 1 ? .title3.weight(.bold) : .body.weight(.medium))
                                    .foregroundStyle(index <= litIndex ? .primary : .tertiary)
                                if index == pathSegments.count - 1, let space = item.space {
                                    Text("位于 \(space.pathString)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                        }
                        .padding(.vertical, 10)

                        if index < pathSegments.count - 1 {
                            Rectangle()
                                .fill(index < litIndex ? Color.accentColor.opacity(0.5) : Color(.systemGray5))
                                .frame(width: 2, height: 20)
                                .padding(.leading, 13)
                        }
                    }
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(Color(.secondarySystemGroupedBackground))
                )

                HStack {
                    Text(item.kind.emoji)
                        .font(.largeTitle)
                    VStack(alignment: .leading) {
                        Text(item.name)
                            .font(.headline)
                        Text(item.kind.title)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(Color.accentColor.opacity(0.08))
                )

                Spacer()
            }
            .padding()
            .navigationTitle("去找它")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("找到了") { dismiss() }
                }
            }
            .onAppear { runGuideAnimation() }
        }
    }

    private func runGuideAnimation() {
        Task {
            for i in 0 ..< pathSegments.count {
                try? await Task.sleep(nanoseconds: 550_000_000)
                await MainActor.run {
                    litIndex = i
                    pulse = false
                    pulse = true
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                }
            }
        }
    }
}
