//
//  ItemFormSheet.swift
//  泡泡
//
//  添加 / 编辑物品：HITL 表单 + Mock AI 识别与推荐。
//

import PhotosUI
import SwiftData
import SwiftUI
import UIKit

struct ItemFormSheet: View {
    var itemToEdit: Item?
    let defaultSpace: SpaceNode
    var onSaved: (Item) -> Void = { _ in }

    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \SpaceNode.sortOrder) private var allNodes: [SpaceNode]
    @Query(sort: \Item.sortOrder) private var allItems: [Item]

    @State private var name: String
    @State private var kind: ItemKind
    @State private var photoData: Data?
    @State private var selectedSpace: SpaceNode
    @State private var expiryDate: Date?
    @State private var hasExpiry: Bool

    @State private var isRecognizing = false
    @State private var aiRecognition: AIRecognitionResult?
    @State private var aiRecommendation: AILocationRecommendation?
    @State private var recognitionTask: Task<Void, Never>?

    private var isEditing: Bool { itemToEdit != nil }

    init(defaultSpace: SpaceNode, itemToEdit: Item? = nil, onSaved: @escaping (Item) -> Void = { _ in }) {
        self.defaultSpace = defaultSpace
        self.itemToEdit = itemToEdit
        self.onSaved = onSaved
        _name = State(initialValue: itemToEdit?.name ?? "")
        _kind = State(initialValue: itemToEdit?.kind ?? .electronics)
        _photoData = State(initialValue: itemToEdit?.photoData)
        _selectedSpace = State(initialValue: itemToEdit?.space ?? defaultSpace)
        _expiryDate = State(initialValue: itemToEdit?.expiryDate)
        _hasExpiry = State(initialValue: itemToEdit?.expiryDate != nil)
    }

    private var spacePickerEntries: [(node: SpaceNode, depth: Int)] {
        SpaceNode.depthFirstPairs(from: SpaceNode.roots(from: allNodes))
    }

    private var trimmedName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        NavigationStack {
            Form {
                if isRecognizing {
                    Section {
                        HStack(spacing: 12) {
                            ProgressView()
                            VStack(alignment: .leading, spacing: 4) {
                                Text("AI 正在识别…")
                                    .font(.subheadline.weight(.medium))
                                Text("识别完成后你可以修改任何字段")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }

                if let ai = aiRecognition, !isRecognizing {
                    Section {
                        aiSuggestionCard(recognition: ai, recommendation: aiRecommendation)
                    } header: {
                        Label("AI 建议（仅供参考）", systemImage: "sparkles")
                    } footer: {
                        Text("点「保存」才会写入收纳地图。AI 不会自动替你保存。")
                    }
                }

                Section {
                    TextField("例如：Nintendo Switch", text: $name)
                        .textInputAutocapitalization(.never)
                } header: {
                    Text("物品名称")
                }

                Section {
                    Picker("物品类型", selection: $kind) {
                        ForEach(ItemKind.allCases) { k in
                            HStack {
                                Text(k.emoji)
                                Text(k.title)
                            }
                            .tag(k)
                        }
                    }
                    .pickerStyle(.navigationLink)
                } header: {
                    Text("类型")
                }

                Section {
                    Picker("所在空间", selection: $selectedSpace) {
                        ForEach(spacePickerEntries, id: \.node.persistentModelID) { entry in
                            HStack {
                                Text(entry.node.pathString)
                                if entry.node.persistentModelID == aiRecommendation?.space?.persistentModelID {
                                    Text("推荐")
                                        .font(.caption2.weight(.semibold))
                                        .padding(.horizontal, 6)
                                        .padding(.vertical, 2)
                                        .background(Color.accentColor.opacity(0.15), in: Capsule())
                                }
                            }
                            .tag(entry.node)
                        }
                    }
                } header: {
                    Text("位置")
                }

                Section {
                    Toggle("设置保质期", isOn: $hasExpiry.animation())
                    if hasExpiry {
                        DatePicker(
                            "到期日",
                            selection: Binding(
                                get: { expiryDate ?? defaultExpiry() },
                                set: { expiryDate = $0 }
                            ),
                            displayedComponents: .date
                        )
                    }
                } header: {
                    Text("保质期（可选）")
                }

                Section {
                    photoSection
                } header: {
                    Text("照片 (可选)")
                } footer: {
                    Text("拍照后 AI 会尝试识别物品名称与类型（演示 Mock）。")
                }
            }
            .navigationTitle(isEditing ? "编辑物品" : "添加物品")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") {
                        recognitionTask?.cancel()
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { save() }
                        .disabled(trimmedName.isEmpty || isRecognizing)
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .onDisappear { recognitionTask?.cancel() }
    }

    @ViewBuilder
    private func aiSuggestionCard(recognition: AIRecognitionResult, recommendation: AILocationRecommendation?) -> some View {
        HStack {
            Text("置信度 \(Int(recognition.confidence * 100))%")
                .font(.caption.weight(.medium))
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(confidenceColor(recognition.confidence).opacity(0.15), in: Capsule())
                .foregroundStyle(confidenceColor(recognition.confidence))
            Spacer()
            if recognition.confidence < 0.7 {
                Label("请核对", systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        }

        Text(recognition.reasoning)
            .font(.caption)
            .foregroundStyle(.secondary)

        if let recommendation {
            Divider()
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: "mappin.and.ellipse")
                    .foregroundStyle(Color.accentColor)
                VStack(alignment: .leading, spacing: 4) {
                    if let space = recommendation.space {
                        Text("建议放入：\(space.pathString)")
                            .font(.subheadline.weight(.medium))
                    }
                    Text(recommendation.reason)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private func confidenceColor(_ value: Double) -> Color {
        value >= 0.8 ? .green : (value >= 0.5 ? .orange : .red)
    }

    private func defaultExpiry() -> Date {
        Calendar.current.date(byAdding: .year, value: 2, to: Date()) ?? Date()
    }

    // MARK: - 照片

    private static var cameraDelegateKey: UInt8 = 0
    private static var photoPickerDelegateKey: UInt8 = 0

    private final class CameraDelegate: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onCapture: (UIImage?) -> Void
        init(onCapture: @escaping (UIImage?) -> Void) { self.onCapture = onCapture }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            onCapture(info[.originalImage] as? UIImage)
            picker.dismiss(animated: true)
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            onCapture(nil)
            picker.dismiss(animated: true)
        }
    }

    private final class PhotoPickerDelegate: NSObject, PHPickerViewControllerDelegate {
        let onPick: (UIImage?) -> Void
        init(onPick: @escaping (UIImage?) -> Void) { self.onPick = onPick }
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            guard let result = results.first else { picker.dismiss(animated: true); return }
            result.itemProvider.loadObject(ofClass: UIImage.self) { [weak picker] object, _ in
                DispatchQueue.main.async {
                    picker?.dismiss(animated: true) { self.onPick(object as? UIImage) }
                }
            }
        }
    }

    private func topmostViewController() -> UIViewController? {
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController
        else { return nil }
        var top = root
        while let p = top.presentedViewController { top = p }
        return top
    }

    private func presentCamera() {
        guard let top = topmostViewController() else { return }
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        let delegate = CameraDelegate { image in
            if let image { applyPhoto(image.jpegData(compressionQuality: 0.82)) }
        }
        objc_setAssociatedObject(picker, &Self.cameraDelegateKey, delegate, .OBJC_ASSOCIATION_RETAIN)
        picker.delegate = delegate
        top.present(picker, animated: true)
    }

    private func presentPhotoPicker() {
        guard let top = topmostViewController() else { return }
        let previous = photoData
        var config = PHPickerConfiguration()
        config.filter = .images
        config.selectionLimit = 1
        let picker = PHPickerViewController(configuration: config)
        let delegate = PhotoPickerDelegate { image in
            if let image {
                applyPhoto(image.jpegData(compressionQuality: 0.82))
            } else {
                photoData = previous
            }
        }
        objc_setAssociatedObject(picker, &Self.photoPickerDelegateKey, delegate, .OBJC_ASSOCIATION_RETAIN)
        picker.delegate = delegate
        top.present(picker, animated: true)
    }

    private func applyPhoto(_ data: Data?) {
        photoData = data
        guard data != nil, !isEditing else { return }
        runAIPipeline()
    }

    private func runAIPipeline() {
        recognitionTask?.cancel()
        recognitionTask = Task {
            isRecognizing = true
            aiRecognition = nil
            aiRecommendation = nil

            let result = await BubbleAgent.runItemEntryPipeline(
                photoData: photoData,
                defaultSpace: defaultSpace,
                allItems: allItems,
                allNodes: allNodes
            )

            guard !Task.isCancelled else {
                isRecognizing = false
                return
            }

            aiRecognition = result.recognition
            aiRecommendation = result.recommendation

            if result.recognition.confidence >= 0.5, !result.recognition.name.isEmpty {
                name = result.recognition.name
                kind = result.recognition.kind
            }

            if let space = result.recommendation.space {
                selectedSpace = space
            }

            if kind == .medicine || kind == .food {
                hasExpiry = true
                expiryDate = defaultExpiry()
            }

            isRecognizing = false
        }
    }

    @ViewBuilder
    private var photoSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let photoData, let ui = UIImage(data: photoData) {
                Image(uiImage: ui)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 72, height: 72)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                Button(role: .destructive) {
                    self.photoData = nil
                    aiRecognition = nil
                    aiRecommendation = nil
                } label: {
                    Label("移除照片", systemImage: "trash")
                }
            }

            Button { presentPhotoPicker() } label: {
                Label("从相册选择", systemImage: "photo.on.rectangle.angled")
            }

            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                Button { presentCamera() } label: {
                    Label("拍照", systemImage: "camera.fill")
                }
            }
        }
    }

    // MARK: - 保存

    private func save() {
        let trimmed = trimmedName
        guard !trimmed.isEmpty else { return }

        let resolvedExpiry = hasExpiry ? (expiryDate ?? defaultExpiry()) : nil

        if let existing = itemToEdit {
            existing.name = trimmed
            existing.kindRaw = kind.rawValue
            existing.photoData = photoData
            existing.expiryDate = resolvedExpiry
            if existing.space?.persistentModelID != selectedSpace.persistentModelID {
                existing.space = selectedSpace
                existing.sortOrder = selectedSpace.items.count
            }
            onSaved(existing)
        } else {
            let order = selectedSpace.items.count
            let item = Item(
                name: trimmed,
                kind: kind,
                sortOrder: order,
                photoData: photoData,
                space: selectedSpace,
                expiryDate: resolvedExpiry
            )
            modelContext.insert(item)
            onSaved(item)
        }
        dismiss()
    }
}
