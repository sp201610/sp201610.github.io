//
//  ReturnReminderService.swift
//  泡泡
//
//  归位提醒：本地通知 + 应用内 banner 兜底。
//

import Foundation
import SwiftData
import UserNotifications

@MainActor
@Observable
final class ReturnReminderService: NSObject, UNUserNotificationCenterDelegate {
    static let shared = ReturnReminderService()

    /// 应用内待处理提醒（通知权限被拒或 App 前台时使用）。
    var pendingBanner: ReturnBanner?

    struct ReturnBanner: Identifiable {
        let id: String
        let itemName: String
        let homePath: String
        let itemID: PersistentIdentifier
    }

    private override init() {
        super.init()
    }

    func configure() {
        UNUserNotificationCenter.current().delegate = self
    }

    func requestAuthorization() async {
        _ = try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
    }

    func schedule(for item: Item, intervalOverride: TimeInterval? = nil) {
        guard item.checkoutAt != nil else { return }
        let interval = intervalOverride ?? AppSettings.reminderInterval
        let homePath = item.space?.pathString ?? "原位置"
        let content = UNMutableNotificationContent()
        content.title = "泡泡 · 归位提醒"
        content.body = "「\(item.name)」还在外面，请放回 \(homePath)"
        content.sound = .default
        content.userInfo = ["itemName": item.name, "homePath": homePath]

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(interval, 5), repeats: false)
        let id = notificationID(for: item)
        let request = UNNotificationRequest(identifier: id, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)

        #if DEBUG
        print("[Reminder] scheduled in \(Int(interval))s for \(item.name)")
        #endif

        // 应用内兜底：前台也能看到 banner
        Task {
            try? await Task.sleep(nanoseconds: UInt64(interval * 1_000_000_000))
            if item.checkoutAt != nil {
                pendingBanner = ReturnBanner(
                    id: id,
                    itemName: item.name,
                    homePath: homePath,
                    itemID: item.persistentModelID
                )
            }
        }
    }

    func cancel(for item: Item) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(
            withIdentifiers: [notificationID(for: item)]
        )
        if pendingBanner?.itemID == item.persistentModelID {
            pendingBanner = nil
        }
    }

    func markReturned(_ item: Item) {
        item.checkoutAt = nil
        cancel(for: item)
    }

    func snooze(for item: Item) {
        cancel(for: item)
        schedule(for: item, intervalOverride: AppSettings.reminderInterval)
    }

    private func notificationID(for item: Item) -> String {
        "return-\(item.persistentModelID.hashValue)"
    }

    // MARK: - UNUserNotificationCenterDelegate

    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        [.banner, .sound]
    }
}
