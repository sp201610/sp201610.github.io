//
//  BubbleAgent.swift
//  泡泡
//
//  Agent 编排：识别 → 推荐，多步决策，演示版走 Mock 降级。
//

import Foundation
import SwiftData

@MainActor
enum BubbleAgent {
    struct PipelineResult {
        let recognition: AIRecognitionResult
        let recommendation: AILocationRecommendation
    }

    static func runItemEntryPipeline(
        photoData: Data?,
        defaultSpace: SpaceNode,
        allItems: [Item],
        allNodes: [SpaceNode]
    ) async -> PipelineResult {
        let recognition: AIRecognitionResult
        if AppSettings.useMockAI {
            recognition = await MockAIService.recognize(from: photoData)
            #if DEBUG
            print("[BubbleAgent] recognize: \(recognition.name) confidence=\(recognition.confidence)")
            #endif
        } else {
            recognition = await MockAIService.recognize(from: photoData)
        }

        let kind = recognition.confidence >= 0.5 ? recognition.kind : .electronics
        let recommendation = MockAIService.recommendLocation(
            for: kind,
            defaultSpace: defaultSpace,
            allItems: allItems,
            allNodes: allNodes
        )

        #if DEBUG
        if let space = recommendation.space {
            print("[BubbleAgent] recommend: \(space.pathString)")
        }
        #endif

        return PipelineResult(recognition: recognition, recommendation: recommendation)
    }

    /// 同容器关联提示（搜索增强，非 LLM）。
    static func siblingItems(for item: Item) -> [Item] {
        guard let space = item.space else { return [] }
        return space.items
            .filter { $0.persistentModelID != item.persistentModelID }
            .sorted { $0.sortOrder < $1.sortOrder }
    }

    static func siblingSummary(for item: Item) -> String? {
        let siblings = siblingItems(for: item)
        guard !siblings.isEmpty else { return nil }
        return siblings.map(\.name).joined(separator: "、")
    }
}
