//
//  Item.swift
//  泡泡
//
//  空间内存放的物品：名称、类型、照片。
//

import Foundation
import SwiftData

enum ItemKind: String, CaseIterable, Identifiable, Sendable {
    case electronics
    case tools
    case medicine
    case food
    case tableware
    case toiletries
    case clothing
    case documents
    case cash
    case keys
    case books
    case stationery
    case sports

    var id: String { rawValue }

    var title: String {
        switch self {
        case .electronics: return "电子产品"
        case .tools: return "维修工具"
        case .medicine: return "药品"
        case .food: return "食品"
        case .tableware: return "餐具"
        case .toiletries: return "洗护用品"
        case .clothing: return "衣物"
        case .documents: return "证件"
        case .cash: return "现金"
        case .keys: return "钥匙"
        case .books: return "书籍"
        case .stationery: return "学习用品"
        case .sports: return "运动装备"
        }
    }

    var emoji: String {
        switch self {
        case .electronics: return "🔌"
        case .tools: return "🔧"
        case .medicine: return "💊"
        case .food: return "🍔"
        case .tableware: return "🍽️"
        case .toiletries: return "🧴"
        case .clothing: return "👕"
        case .documents: return "📄"
        case .cash: return "💰"
        case .keys: return "🔑"
        case .books: return "📚"
        case .stationery: return "✏️"
        case .sports: return "⚽"
        }
    }
}

@Model
final class Item {
    var name: String
    var kindRaw: String
    var sortOrder: Int
    var createdAt: Date

    @Attribute(.externalStorage)
    var photoData: Data?

    var space: SpaceNode?

    /// 标记取出时间；非 nil 表示物品当前不在原位。
    var checkoutAt: Date?

    /// 保质期（可选，药品/食品场景）。
    var expiryDate: Date?

    init(
        name: String,
        kind: ItemKind,
        sortOrder: Int = 0,
        photoData: Data? = nil,
        space: SpaceNode? = nil,
        checkoutAt: Date? = nil,
        expiryDate: Date? = nil
    ) {
        self.name = name
        self.kindRaw = kind.rawValue
        self.sortOrder = sortOrder
        self.createdAt = Date()
        self.photoData = photoData
        self.space = space
        self.checkoutAt = checkoutAt
        self.expiryDate = expiryDate
    }

    var kind: ItemKind {
        ItemKind(rawValue: kindRaw) ?? .electronics
    }

    var isCheckedOut: Bool {
        checkoutAt != nil
    }
}
