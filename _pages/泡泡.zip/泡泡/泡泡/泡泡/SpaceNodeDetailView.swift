//
//  SpaceNodeDetailView.swift
//  泡泡
//
//  空间详情页：展示大图、基本信息、所存物品、取出/归位。
//

import SwiftData
import SwiftUI
import UIKit

private enum ItemFormTarget: Identifiable {
    case add
    case edit(Item)

    var id: String {
        switch self {
        case .add: return "_add"
        case .edit(let item): return String(describing: item.persistentModelID)
        }
    }

    var itemToEdit: Item? {
        if case .edit(let item) = self { return item }
        return nil
    }
}

struct SpaceNodeDetailView: View {
    @Bindable var node: SpaceNode

    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext

    @State private var itemFormTarget: ItemFormTarget?
    @State private var itemPendingDelete: Item?

    private var ancestorPath: [SpaceNode] {
        var path: [SpaceNode] = []
        var current = node.parent
        while let p = current {
            path.append(p)
            current = p.parent
        }
        return path.reversed()
    }

    private var sortedItems: [Item] {
        node.items.sorted { $0.sortOrder < $1.sortOrder }
    }

    private var sortedChildren: [SpaceNode] {
        node.sortedChildren()
    }

    var body: some View {
        List {
            Section {
                if let data = node.photoData, let ui = UIImage(data: data) {
                    Image(uiImage: ui)
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity)
                        .frame(height: 280)
                        .clipped()
                        .listRowInsets(EdgeInsets())
                } else {
                    ZStack {
                        Rectangle()
                            .fill(.quaternary.opacity(0.25))
                        Image(systemName: "photo")
                            .font(.system(size: 48, weight: .light))
                            .foregroundStyle(.tertiary)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 220)
                    .listRowInsets(EdgeInsets())
                }
            }

            Section {
                HStack(spacing: 10) {
                    Image(systemName: node.kind.systemImage)
                        .font(.title2)
                        .symbolRenderingMode(.hierarchical)
                        .foregroundStyle(.secondary)
                    Text(node.kindDisplayName)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Text(node.name)
                    .font(.title.weight(.bold))
                    .lineLimit(3)

                if !ancestorPath.isEmpty {
                    HStack(spacing: 4) {
                        Text("位于")
                            .foregroundStyle(.secondary)
                        Text(ancestorPath.map(\.name).joined(separator: " ▸ "))
                            .fontWeight(.medium)
                    }
                    .font(.subheadline)
                }
            }

            if !sortedChildren.isEmpty {
                Section {
                    ForEach(sortedChildren) { child in
                        NavigationLink(destination: SpaceNodeDetailView(node: child)) {
                            HStack(spacing: 10) {
                                Image(systemName: child.kind.systemImage)
                                    .font(.title3)
                                    .symbolRenderingMode(.hierarchical)
                                    .foregroundStyle(.secondary)
                                    .frame(width: 28)

                                VStack(alignment: .leading, spacing: 2) {
                                    Text(child.name)
                                        .font(.body.weight(.medium))
                                        .lineLimit(1)
                                    Text(child.kindDisplayName)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer(minLength: 0)

                                if !child.items.isEmpty {
                                    Text("\(child.items.count) 件物品")
                                        .font(.caption)
                                        .foregroundStyle(.tertiary)
                                }
                            }
                        }
                    }
                } header: {
                    Text("子空间")
                }
            }

            Section {
                if node.items.isEmpty {
                    VStack(spacing: 8) {
                        Image(systemName: "shippingbox")
                            .font(.system(size: 36, weight: .light))
                            .foregroundStyle(.quaternary)
                        Text("这里还是空的")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text("点右上角 + 添加物品，拍照可触发 AI 识别")
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 40)
                } else {
                    ForEach(sortedItems) { item in
                        itemRow(item)
                    }
                }
            } header: {
                HStack {
                    Text("物品")
                    Spacer()
                    Text("\(node.items.count) 件")
                }
            }
        }
        .listStyle(.plain)
        .confirmationDialog(
            "确定删除「\(itemPendingDelete?.name ?? "")」？",
            isPresented: Binding(
                get: { itemPendingDelete != nil },
                set: { if !$0 { itemPendingDelete = nil } }
            ),
            titleVisibility: .visible,
            presenting: itemPendingDelete
        ) { item in
            Button("删除", role: .destructive) {
                ReturnReminderService.shared.cancel(for: item)
                modelContext.delete(item)
                itemPendingDelete = nil
            }
            Button("取消", role: .cancel) {
                itemPendingDelete = nil
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .ignoresSafeArea(edges: .top)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text(node.name)
                    .font(.headline)
                    .lineLimit(1)
            }
            ToolbarItem(placement: .primaryAction) {
                Button {
                    itemFormTarget = .add
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(item: $itemFormTarget) { target in
            ItemFormSheet(defaultSpace: node, itemToEdit: target.itemToEdit) { _ in
                itemFormTarget = nil
            }
        }
    }

    @ViewBuilder
    private func itemRow(_ item: Item) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Text(item.kind.emoji)
                    .font(.title2)
                    .frame(width: 32, height: 32)

                if let data = item.photoData, let ui = UIImage(data: data) {
                    Image(uiImage: ui)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 36, height: 36)
                        .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                }

                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 6) {
                        Text(item.name)
                            .font(.body.weight(.medium))
                            .lineLimit(1)
                        if item.isCheckedOut {
                            Text("已取出")
                                .font(.caption2.weight(.semibold))
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.orange.opacity(0.15), in: Capsule())
                                .foregroundStyle(.orange)
                        }
                    }
                    Text(item.kind.title)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if let expiry = item.expiryDate {
                        Text("保质期至 \(expiry.formatted(date: .abbreviated, time: .omitted))")
                            .font(.caption2)
                            .foregroundStyle(.tertiary)
                    }
                }
            }

            HStack(spacing: 8) {
                if item.isCheckedOut {
                    Button {
                        ReturnReminderService.shared.markReturned(item)
                    } label: {
                        Label("已归位", systemImage: "checkmark.circle.fill")
                            .font(.caption.weight(.semibold))
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)

                    Button {
                        ReturnReminderService.shared.snooze(for: item)
                    } label: {
                        Label("稍后提醒", systemImage: "clock")
                            .font(.caption)
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                } else {
                    Button {
                        item.checkoutAt = Date()
                        ReturnReminderService.shared.schedule(for: item)
                    } label: {
                        Label("标记取出", systemImage: "hand.raised.fill")
                            .font(.caption.weight(.semibold))
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }
            }
        }
        .padding(.vertical, 4)
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(role: .destructive) {
                itemPendingDelete = item
            } label: {
                Label("删除", systemImage: "trash")
            }
        }
        .onTapGesture {
            itemFormTarget = .edit(item)
        }
    }
}
