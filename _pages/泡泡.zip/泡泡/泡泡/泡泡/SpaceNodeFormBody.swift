//
//  SpaceNodeFormBody.swift
//  泡泡
//
//  新建 / 编辑共用的表单区块。
//

import PhotosUI
import SwiftData
import SwiftUI
import UIKit

struct SpaceNodeFormBody: View {
    @Binding var name: String
    @Binding var kind: SpaceKind
    @Binding var parent: SpaceNode?
    @Binding var photoData: Data?
    @Binding var customKindName: String

    let allNodes: [SpaceNode]
    /// 编辑时传入，从「上层空间」候选中排除该节点及其子树；新建时为 `nil`。
    let excludeSubtreeRoot: SpaceNode?

    private var parentPickerEntries: [(node: SpaceNode, depth: Int)] {
        let roots = SpaceNode.roots(from: allNodes)
        let pairs = SpaceNode.depthFirstPairs(from: roots)
        guard let blocked = excludeSubtreeRoot else {
            return pairs
        }
        let invalid = SpaceNode.invalidUpperSpacePickerSubtree(from: blocked)
        return pairs.filter { !invalid.contains($0.node.persistentModelID) }
    }

    var body: some View {
        Group {
            Section {
                TextField("例如：玄关抽屉", text: $name)
                    .textInputAutocapitalization(.never)
            } header: {
                Text("位置名称")
            } footer: {
                Text("给这处空间起一个你一眼能认出的名字。")
            }

            Section {
                Picker("空间类型", selection: $kind) {
                    ForEach(SpaceKind.allCases) { k in
                        Label(k.title, systemImage: k.systemImage).tag(k)
                    }
                }

                if kind == .custom {
                    TextField("自定义类型名称", text: $customKindName)
                        .textInputAutocapitalization(.never)
                }
            } header: {
                Text("类型")
            }

            Section {
                Picker("放在哪里", selection: $parent) {
                    Text("顶层（收纳地图根上）")
                        .tag(SpaceNode?.none)
                    ForEach(parentPickerEntries, id: \.node.persistentModelID) { entry in
                        Text(title(for: entry.node, depth: entry.depth))
                            .tag(Optional(entry.node))
                    }
                }
            } header: {
                Text("上层空间")
            } footer: {
                Text("可选：放进已有的上层空间（如房间、柜子等）；不选则作为顶层位置。")
            }

            Section {
                photoSection
            } header: {
                Text("视觉记忆")
            } footer: {
                Text("拍一张或从相册选一张，帮助以后一眼想起是哪里。")
            }
        }
    }

    // MARK: - 相机 / 相册（直接 UIKit present，避免 SwiftUI 双层 sheet 冲突）

    private static var cameraDelegateKey: UInt8 = 0
    private static var photoPickerDelegateKey: UInt8 = 0

    private final class CameraDelegate: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onCapture: (UIImage?) -> Void

        init(onCapture: @escaping (UIImage?) -> Void) {
            self.onCapture = onCapture
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            onCapture(info[.originalImage] as? UIImage)
            picker.dismiss(animated: true)
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            onCapture(nil)
            picker.dismiss(animated: true)
        }
    }

    private final class PhotoPickerDelegate: NSObject, PHPickerViewControllerDelegate {
        let onPick: (UIImage?) -> Void

        init(onPick: @escaping (UIImage?) -> Void) {
            self.onPick = onPick
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            guard let result = results.first else {
                picker.dismiss(animated: true)
                return
            }
            result.itemProvider.loadObject(ofClass: UIImage.self) { [weak picker] object, _ in
                DispatchQueue.main.async {
                    picker?.dismiss(animated: true) {
                        self.onPick(object as? UIImage)
                    }
                }
            }
        }
    }

    private func topmostViewController() -> UIViewController? {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let root = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController
        else { return nil }

        var top = root
        while let presented = top.presentedViewController {
            top = presented
        }
        return top
    }

    private func presentCamera() {
        guard let top = topmostViewController() else { return }
        let previous = photoData

        let picker = UIImagePickerController()
        picker.sourceType = .camera

        let delegate = CameraDelegate { image in
            if let image {
                photoData = image.jpegData(compressionQuality: 0.82)
            } else {
                photoData = previous
            }
        }

        objc_setAssociatedObject(picker, &Self.cameraDelegateKey, delegate, .OBJC_ASSOCIATION_RETAIN)
        picker.delegate = delegate
        top.present(picker, animated: true)
    }

    private func presentPhotoPicker() {
        guard let top = topmostViewController() else { return }
        let previous = photoData

        var config = PHPickerConfiguration()
        config.filter = .images
        config.selectionLimit = 1

        let picker = PHPickerViewController(configuration: config)
        let delegate = PhotoPickerDelegate { image in
            if let image {
                photoData = image.jpegData(compressionQuality: 0.82)
            } else {
                photoData = previous
            }
        }

        objc_setAssociatedObject(picker, &Self.photoPickerDelegateKey, delegate, .OBJC_ASSOCIATION_RETAIN)
        picker.delegate = delegate
        top.present(picker, animated: true)
    }

    @ViewBuilder
    private var photoSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let photoData, let ui = UIImage(data: photoData) {
                Image(uiImage: ui)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 72, height: 72)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

                Button(role: .destructive) {
                    self.photoData = nil
                } label: {
                    Label("移除照片", systemImage: "trash")
                }
            }

            Button {
                presentPhotoPicker()
            } label: {
                Label("从相册选择", systemImage: "photo.on.rectangle.angled")
            }

            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                Button {
                    presentCamera()
                } label: {
                    Label("拍照", systemImage: "camera.fill")
                }
            }
        }
    }

    private func title(for node: SpaceNode, depth: Int) -> String {
        let prefix = String(repeating: "　", count: depth * 2)
        return "\(prefix)\(node.name)"
    }


}
