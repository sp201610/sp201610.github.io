---
name: swiftui-gesture-conflicts
description: SwiftUI gesture patterns that work vs conflict in this project
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5ac892eb-650c-417e-8ae1-310024f71fb1
---

# SwiftUI Gesture Patterns

## What works

- **Favorite swipe**: Use `.swipeActions(edge: .leading, allowsFullSwipe: true)` — system-native, no conflicts with other gestures.
- **Edit/Delete swipe**: Use `.swipeActions(edge: .trailing, allowsFullSwipe: false)` — system-native.
- **Chevron expand button**: Standard `Button` with `.buttonStyle(.plain)` inside a List row.
- **Navigation tap**: `.onTapGesture` on a specific sub-view (not the entire row), with `.navigationDestination(item:)` for programmatic navigation.
- **Swipe in ScrollView**: `.swipeActions` does NOT work in ScrollView. Must use `List` for native swipe actions, or implement custom DragGesture.

## What doesn't work

- **Custom DragGesture for right-swipe**: Always conflicts with List's built-in swipe gesture system and ScrollView scrolling. The UIPanGestureRecognizer from DragGesture interferes even when direction-guarded in onChanged.
- **UIKit UIPanGestureRecognizer overlay**: UIViewRepresentable overlay blocks taps on underlying SwiftUI views. Even with `delaysTouchesEnded = false`, the overlay consumes touch events.
- **Mixing custom pan gestures with List**: Any UIPanGestureRecognizer added to a List row or its children will conflict with the List's internal swipe gestures.

## Sheet management

- **Never nest `.sheet` in `.sheet`**: SwiftUI only supports one sheet at a time. For camera/photo picker inside a sheet, use UIKit direct presentation via `topmostViewController()`.
- **Photo picker cache**: Cache existing photo before presenting picker, restore if cancelled.

**Why:** Multiple failed attempts at custom right-swipe gesture. System swipeActions is the only reliable approach.
**How to apply:** Don't try custom DragGesture for swipe actions. Use `.swipeActions` or accept the limitation.
