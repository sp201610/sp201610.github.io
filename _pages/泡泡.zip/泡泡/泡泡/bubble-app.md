---
name: bubble-app
description: "泡泡 iOS app — SwiftData storage organization app with spaces, items, favorites, search, Mock AI Agent"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5ac892eb-650c-417e-8ae1-310024f71fb1
---

# 泡泡 · 收纳地图

iOS app for organizing physical storage spaces hierarchically. Built with SwiftUI + SwiftData + Mock AI Agent.

## Architecture

- `SpaceNode`: @Model — hierarchical spaces (rooms, cabinets, drawers, etc.)
- `Item`: @Model — items with kind/emoji/photo, checkoutAt, expiryDate
- `BubbleAgent`: recognize → recommend pipeline (Mock)
- `MockAIService`: prebuilt AI responses for demo
- `ReturnReminderService`: local notifications + in-app banner
- `DemoSeedData`: one-tap demo map import
- `FindItGuideView`: path animation for search results

## Demo Flow

1. Empty map → toolbar「导入演示」
2. Search「车钥匙」→ siblings +「去找它」
3. Add item in 药盒 → photo → AI mock → save
4. Mark 螺丝刀 checked out → 15s reminder (demo mode)

## Key Patterns

- **Sheet conflict**: Never use `.sheet` inside another `.sheet`. Use UIKit-direct presentation for camera/photo picker.
- **HITL**: AI never auto-inserts; `ItemFormSheet.save()` required.
- **List vs ScrollView**: `.swipeActions` only works inside `List`.

## Files

| File | Purpose |
|---|---|
| `BubbleAgent.swift` | Agent orchestration |
| `MockAIService.swift` | Fake AI responses |
| `ReturnReminderService.swift` | Return reminders |
| `DemoSeedData.swift` | Demo seed |
| `FindItGuideView.swift` | Find-it animation |
| `AppSettings.swift` | demoMode, intervals |
| `ItemFormSheet.swift` | HITL form + AI card |
| `ContentView.swift` | Search + demo import |

**Why:** App project context for future development.
